<?php
  class Common
    { 

    function __construct() {
    }
    public function validateRequest() {
        foreach (getallheaders() as $name => $value) {
            
        }
        return TRUE;
    }

}
