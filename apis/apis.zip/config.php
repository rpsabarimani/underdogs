<?php

date_default_timezone_set('Asia/Calcutta');
$PDO = new PDO('mysql:host=localhost;dbname=db_4tigo_production', 'root', '');

?>
